document.addEventListener("DOMContentLoaded", function () {
    const darkModeToggle = document.getElementById("darkmode");
    const body = document.body;

    // Check local storage for dark mode preference
    if (localStorage.getItem("darkMode") === "true") {
        body.classList.add("dark");
        darkModeToggle.classList.replace("bx-moon", "bx-sun");
    }

    // Toggle dark mode on button click
    darkModeToggle.addEventListener("click", function () {
        body.classList.toggle("dark");
        const isDarkMode = body.classList.contains("dark");
        localStorage.setItem("darkMode", isDarkMode);

        // Toggle icon
        if (isDarkMode) {
            darkModeToggle.classList.replace("bx-moon", "bx-sun");
        } else {
            darkModeToggle.classList.replace("bx-sun", "bx-moon");
        }
    });
});
